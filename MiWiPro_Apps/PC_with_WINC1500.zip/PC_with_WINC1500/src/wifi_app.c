/**
* \file  wifi_app.c
*
* Copyright (c) 2019 Microchip Technology Inc. and its subsidiaries.
*
* \asf_license_start
*
* \page License
*
* Subject to your compliance with these terms, you may use Microchip
* software and any derivatives exclusively with Microchip products.
* It is your responsibility to comply with third party license terms applicable
* to your use of third party software (including open source software) that
* may accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
* INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
* AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
* LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
* LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
* SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
* POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
* ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
* RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*
* \asf_license_stop
*
*/
/****************************** INCLUDES **************************************/
#include <asf.h>
#include "wifi_app.h"
#include "driver/include/m2m_wifi.h"
#include "MQTTClient/Wrapper/mqtt.h"
#include "socket/include/socket.h"
#include "app.h"

/* Application instruction phrase. */
#define STRING_EOL    "\r\n"
#define STRING_HEADER "-- WINC1500 Wi-Fi MQTT chat example --"STRING_EOL \
	"-- "BOARD_NAME " --"STRING_EOL	\
	"-- Compiled: "__DATE__ " "__TIME__ " --"STRING_EOL

/** User name of chat. */
char mqtt_user[64] = "" ;
char mqtt_password[64] = "" ;
char mqtt_client_id[64] = "" ;
char wifiAppTopic[100] = "" ;

/* Instance of MQTT service. */
static struct mqtt_module mqtt_inst;

/* Receive buffer of the MQTT service. */
static unsigned char mqtt_read_buffer[MAIN_MQTT_BUFFER_SIZE];
static unsigned char mqtt_send_buffer[MAIN_MQTT_BUFFER_SIZE];

/** Prototype for MQTT subscribe Callback */
void SubscribeHandler(MessageData *msgData);

// Callback to get the Wi-Fi status update
static void wifi_callback(uint8 msg_type, void *msg_data)
{
	tstrM2mWifiStateChanged *msg_wifi_state ;
	uint8 *msg_ip_addr ;

	switch (msg_type)
	{
		case M2M_WIFI_RESP_CON_STATE_CHANGED:
			msg_wifi_state = (tstrM2mWifiStateChanged *)msg_data;
			if (msg_wifi_state->u8CurrState == M2M_WIFI_CONNECTED)
			{
				/* If Wi-Fi is connected. */
				printf("Wi-Fi connected\r\n") ;
				m2m_wifi_request_dhcp_client() ;
			} 
			else if (msg_wifi_state->u8CurrState == M2M_WIFI_DISCONNECTED)
			{
				/* If Wi-Fi is disconnected. */
				printf("Wi-Fi disconnected\r\n") ;
				m2m_wifi_connect((char *)MAIN_WLAN_SSID, sizeof(MAIN_WLAN_SSID),
					MAIN_WLAN_AUTH, (char *)MAIN_WLAN_PSK, M2M_WIFI_CH_ALL) ;
				/* Disconnect from MQTT broker. */
				/* Force close the MQTT connection, because cannot send a disconnect message to the broker when network is broken. */
				mqtt_disconnect(&mqtt_inst, 1) ;
			}
		break ;
		case M2M_WIFI_REQ_DHCP_CONF:
			msg_ip_addr = (uint8 *)msg_data ;
			printf("Wi-Fi IP is %u.%u.%u.%u\r\n",
				msg_ip_addr[0], msg_ip_addr[1], msg_ip_addr[2], msg_ip_addr[3]) ;
			/* Try to connect to MQTT broker when Wi-Fi was connected. */
			mqtt_connect(&mqtt_inst, main_mqtt_broker) ;
		break ;
		default:
		break ;
	}
}

// Callback to get the Socket event
static void socket_event_handler(SOCKET sock, uint8_t msg_type, void *msg_data)
{
	mqtt_socket_event_handler(sock, msg_type, msg_data) ;
}

// Callback of gethostbyname function
static void socket_resolve_handler(uint8_t *domain_name, uint32_t server_ip)
{
	mqtt_socket_resolve_handler(domain_name, server_ip) ;
}

// Callback to receive the subscribed message
void SubscribeHandler(MessageData *msgData)
{
	/* You received publish message which you had subscribed. */
	/* Print Topic and message */
	printf("\r\n %.*s",msgData->topicName->lenstring.len,msgData->topicName->lenstring.data) ;// topic
	printf(" >> ") ;
	printf("%.*s",msgData->message->payloadlen,(char *)msgData->message->payload) ;// message
	if (strstr((char*)msgData->message->payload, "downlink_message"))
	{
		// inform the Application layer only when it's a downlink message
//TODO: define in app.c		app_mqtt_downlink((char *)msgData->message->payload) ;
	}
}

// Callback to get the MQTT status update
static void mqtt_callback(struct mqtt_module *module_inst, int type, union mqtt_data *data)
{
	switch (type)
	{
		case MQTT_CALLBACK_SOCK_CONNECTED:
		{
			/*
			 * If connecting to broker server is complete successfully, Start sending CONNECT message of MQTT.
			 * Or else retry to connect to broker server.
			*/
			if (data->sock_connected.result >= 0)
			{
				printf("\r\nConnecting to Broker...") ;
				//mqtt_connect_broker(module_inst, 1, NULL, NULL, mqtt_user, NULL, NULL, 0, 0, 0) ;
				mqtt_connect_broker(module_inst, 1, mqtt_user, mqtt_password, mqtt_client_id, NULL, NULL, 0, 0, 0) ;

			}
			else
			{
				printf("Connect fail to server(%s)! retry it automatically.\r\n", main_mqtt_broker) ;
				mqtt_connect(module_inst, main_mqtt_broker) ; /* Retry that. */
			}
		}
		break;
		case MQTT_CALLBACK_CONNECTED:
			if (data->connected.result == MQTT_CONN_RESULT_ACCEPT)
			{
				// Subscribe chat topic
				mqtt_subscribe(module_inst, ACTUATOR_TOPIC, 0, SubscribeHandler) ;
				printf("Preparation of the chat has been completed.\r\n") ;

				// inform the app layer that wifi app is ready
				app_set_ready() ;
				//wifi_app_publish_data(TEMP_DATA_TO_PUBLISH, strlen(TEMP_DATA_TO_PUBLISH)) ;

			}
			else 
			{
				/* Cannot connect for some reason. */
				printf("MQTT broker decline your access! error code %d\r\n", data->connected.result) ;
			}
		break ;
		case MQTT_CALLBACK_DISCONNECTED:
			/* Stop timer and USART callback. */
			printf("MQTT disconnected\r\n") ;
		break ;
	}
}

// Configure MQTT service
 static void configure_mqtt(void)
{
	struct mqtt_config mqtt_conf ;
	int result ;

	mqtt_get_config_defaults(&mqtt_conf) ;
	/* To use the MQTT service, it is necessary to always set the buffer and the timer. */
	mqtt_conf.read_buffer = mqtt_read_buffer ;
	mqtt_conf.read_buffer_size = MAIN_MQTT_BUFFER_SIZE ;
	mqtt_conf.send_buffer = mqtt_send_buffer ;
	mqtt_conf.send_buffer_size = MAIN_MQTT_BUFFER_SIZE ;
	result = mqtt_init(&mqtt_inst, &mqtt_conf) ;
	if (result < 0)
	{
		printf("MQTT initialization failed. Error code is (%d)\r\n", result) ;
		while (1) {
		}
	}
	result = mqtt_register_callback(&mqtt_inst, mqtt_callback) ;
	if (result < 0)
	{
		printf("MQTT register callback failed. Error code is (%d)\r\n", result) ;
		while (1) {
		}
	}
}

void wifi_app_init(void)
{
	tstrWifiInitParam param ;
	int8_t ret ;
	char topic[strlen(SENSOR_TOPIC) + 1] ;

	/* Initialize the MQTT service. */
	configure_mqtt() ;

	/* Initialize the BSP. */
	nm_bsp_init() ;

	/* Setup user name first */
	sprintf(mqtt_user, "%s", MAIN_MQTT_USER) ;
	printf("User : %s\r\n", mqtt_user) ;
	sprintf(mqtt_password, "%s", MAIN_MQTT_PASS) ;
	printf("Password : %s\r\n", mqtt_password) ;
	sprintf(mqtt_client_id, "%s", MAIN_MQTT_CLIENT_ID) ;
	printf("Client ID : %s\r\n", mqtt_client_id) ;
	sprintf(topic, "%s", SENSOR_TOPIC) ;
	printf("\r\nTopic : %s",topic) ;
	sprintf(wifiAppTopic, "%s", topic) ;

	/* Initialize Wi-Fi parameters structure. */
	memset((uint8_t *)&param, 0, sizeof(tstrWifiInitParam)) ;

	/* Initialize Wi-Fi driver with data and status callbacks. */
	param.pfAppWifiCb = wifi_callback ; /* Set Wi-Fi event callback. */
	ret = m2m_wifi_init(&param) ;
	if (M2M_SUCCESS != ret)
	{
		printf("main: m2m_wifi_init call error!(%d)\r\n", ret) ;
		while (1) { /* Loop forever. */
		}
	}

	/* Initialize socket interface. */
	socketInit() ;
	registerSocketCallback(socket_event_handler, socket_resolve_handler) ;

	/* Connect to router. */
	m2m_wifi_connect((char *)MAIN_WLAN_SSID, sizeof(MAIN_WLAN_SSID),
	  MAIN_WLAN_AUTH, (char *)MAIN_WLAN_PSK, M2M_WIFI_CH_ALL);

	// Initialize SysTick counter
	if (SysTick_Config(system_cpu_clock_get_hz() / 1000))
	{
		puts("ERR>> Systick configuration error\r\n") ;
		while (1) ;
	}
}

//void wifi_app_publish_data(const char *data, uint8_t len)
void wifi_app_publish_data(void *data, uint8_t len)
{
	mqtt_publish(&mqtt_inst, wifiAppTopic, data, len, 0, 0) ;
}

void wifi_app_publish_topic(const char *topic, void *data, uint8_t len)
{
	mqtt_publish(&mqtt_inst, topic, data, len, 0, 0) ;
}

// to be called in main while loop
void wifi_app_task(void)
{
	/* Handle pending events from network controller. */
	m2m_wifi_handle_events(NULL) ;
	
	if(mqtt_inst.isConnected)
	{
		mqtt_yield(&mqtt_inst, 0) ;
	}
}

