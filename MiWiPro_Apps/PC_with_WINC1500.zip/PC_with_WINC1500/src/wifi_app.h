#ifndef WIFI_APP_H_INCLUDED
#define WIFI_APP_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

/* Max size of UART buffer. */
#define MAIN_BUFFER_SIZE 64

/* Max size of MQTT buffer. */
#define MAIN_MQTT_BUFFER_SIZE 512

/* Limitation of user name. */
#define MAIN_USER_NAME_SIZE 64

// Main Topic
// MQTT Connection Parameters
// mydevice Cayenne
#define MAIN_MQTT_USER "99ef6000-fa32-11e7-80de-0f99a32d7a93" //"gateway"
#define MAIN_MQTT_PASS "4fceb5b9a4a2a10c705234ccd3d38dd1528a5c39" // NULL
#define MAIN_MQTT_CLIENT_ID "e82cde60-a65f-11ea-b767-3f1a8f1211ba" // NULL

// MQTT Topic to publish (sensor)
// Check documentation on: https://developers.mydevices.com/cayenne/docs/cayenne-mqtt-api/
#define SENSOR_TOPIC "v1/" MAIN_MQTT_USER "/things/" MAIN_MQTT_CLIENT_ID "/data/"	// send Sensor data to channel x

// e.g. temp,c=20.7

// MQTT Topic to subscribe (actuator)
#define ACTUATOR_TOPIC  "v1/" MAIN_MQTT_USER "/things/" MAIN_MQTT_CLIENT_ID "/cmd/2"	// receive actuator command on channel 2

#define TEMP_DATA_TO_PUBLISH	"temp,c=25.0"

/*
 * A MQTT broker server which was connected.
 * m2m.eclipse.org is public MQTT broker.
 */
static const char main_mqtt_broker[] = "mqtt.mydevices.com" ; //"mqtt.eclipse.org";

/** Wi-Fi Settings */
#define MAIN_WLAN_SSID	"AxessGD" //"TP-Link_9446" /* < Destination SSID */
#define MAIN_WLAN_AUTH	M2M_WIFI_SEC_WPA_PSK /* < Security manner */
#define MAIN_WLAN_PSK	"Gd306b16v!" //"84250018" /* < Password for Destination SSID */

#ifdef __cplusplus
}
#endif

void wifi_app_init(void) ;
void wifi_app_publish_data(void *data, uint8_t len) ;
//void wifi_app_publish_data(const char *data, uint8_t len) ;
void wifi_app_publish_topic(const char *topic, void *data, uint8_t len) ;
void wifi_app_task(void) ;
bool wifi_app_ready(void) ;

#endif /* WIFI_APP_H_INCLUDED */
