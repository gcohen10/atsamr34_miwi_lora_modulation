/**
* \file  miwi_lora_app.c
*
* Copyright (c) 2019 Microchip Technology Inc. and its subsidiaries.
*
* \asf_license_start
*
* \page License
*
* Subject to your compliance with these terms, you may use Microchip
* software and any derivatives exclusively with Microchip products.
* It is your responsibility to comply with third party license terms applicable
* to your use of third party software (including open source software) that
* may accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
* INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
* AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
* LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
* LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
* SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
* POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
* ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
* RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*
* \asf_license_stop
*
*/
/****************************** INCLUDES **************************************/
#include <asf.h>
#include "miwi_lora_app.h"
#include "radio_registers_SX1276.h"
#include "radio_driver_SX1276.h"
#include "radio_driver_hal.h"
#include "radio_get_set.h"
#include "MiWi.h"
#include "NVM.h"
#include "SymbolTime.h"
#include "app.h"

/************************** Global variables ***********************************/
#if ADDITIONAL_NODE_ID_SIZE > 0
uint8_t AdditionalNodeID[ADDITIONAL_NODE_ID_SIZE] = {0x01} ;
#endif

uint8_t set_ScanDuration,set_SearchDuration ;

/************************** Extern variables ***********************************/
extern uint8_t rxData[] ;
extern volatile uint8_t	MACTxBuffer[] ;
extern int16_t LBT_TR ;
extern int32_t LBT_LIMIT ;

/****************************** FUNCTIONS **************************************/
static void miwilora_radio_init(void) ;

static void miwilora_radio_init(void)
{
	SX1276_Reset() ;
	SX1276_Config() ;
	SX1276_RX_INIT() ;
	
	MiMAC_SetChannel(INIT_CHANNEL_NUM) ;
	
	// SignalBw [0:  7.8kHz, 1: 10.4kHz, 2: 15.6kHz, 3: 20.8kHz, 4: 31.25kHz,
	//			 5: 41.7kHz, 6: 62.5kHz, 7: 125kHz,  8: 250kHz,  9: 500kHz, other: Reserved]
	SX1276LoRaSetSignalBandwidth(7) ;
	
	// SpreadingFactor [6: 64, 7: 128, 8: 256, 9: 512, 10: 1024, 11: 2048, 12: 4096  chips]
	SX1276LoRaSetSpreadingFactor(7) ;
	
	// RF Output Power
	SX1276LoRaSetRFPower(TX_OUTPUT_POWER) ;
}

void MiWiLoRa_app_init(void)
{
	miwilora_radio_init() ;
	MiApp_ProtocolInit(false) ;
	set_ScanDuration = 14 ;
	set_SearchDuration = 14 ;
}

void MiWiLoRa_app_wakeup_radio(void)
{
	HAL_TCXOPowerOn() ;
	/* Initialize the Radio Hardware */
	HAL_RadioInit() ;
	/* Reset the radio */
	RADIO_Reset();
	Radio_WriteMode(MODE_STANDBY, radioConfiguration.modulation, 0) ;

	miwilora_radio_init() ;
}

void MiWiLoRa_app_sleep_radio(void)
{
	uint8_t op_mode, current_mode ;
	uint8_t new_mode = 0x00 ;
	
	/* Power On the TCXO Oscillator */
	HAL_TCXOPowerOn() ;
	
	/* Reset the radio */
	RADIO_Reset() ;
	
	op_mode = RADIO_RegisterRead(0x01) ;
	current_mode = op_mode & 0x07 ;
	
	if (new_mode != current_mode)
	{
		// Do the actual mode switch.
		op_mode &= ~0x07 ;		// Clear old mode bits
		op_mode |= new_mode ;	// Set new mode bits
		while (op_mode != RADIO_RegisterRead(0x01))
		{
			RADIO_RegisterWrite(0x01, op_mode) ;
		}
	}
	/* Power off the oscillator after putting radio to sleep */
	HAL_TCXOPowerOff() ;
	
	/* Disable the SPI interface */
	HAL_RadioDeInit() ;	
}

void MiWiLoRa_app_rx(void)
{
	if (MiApp_MessageAvailable())
	{
		printf("***************************\r\n") ;
		printf("> Data Received.....\n\r") ;
		printf("SRC PID: %.2x ", rxMessage.SourcePANID) ;
		printf("SRC ADR: %.2x%.2x\r\n", rxMessage.SourceAddress[1], rxMessage.SourceAddress[0]) ;
		printf("Length: %d ", rxMessage.PayloadSize) ;
		printf("RSSI: %ddBm\r\n", rxMessage.PacketRSSI) ;

		// pass the message received and the source address to application layer
		uint16_t srcAddr = (rxMessage.SourceAddress[1] * 256) + (rxMessage.SourceAddress[0]) ;
		app_get_message(srcAddr, rxMessage.Payload, rxMessage.PayloadSize) ;

		printf("Payload: ");
		for(uint8_t i = 0; i < rxMessage.PayloadSize; i++)
		{
			printf("%.2x ",*(uint8_t*)(rxMessage.Payload + i)) ;
		}
		printf("\n\r") ;
		MiApp_DiscardMessage();
	}
}

bool MiWiLoRa_app_start_network(void)
{
	uint32_t OperatingChannel = 0x00300000;//0xFFFFFFFF;
	MiApp_ConnectionMode(ENABLE_ALL_CONN);
	if(MiApp_StartConnection(START_CONN_ENERGY_SCN, set_ScanDuration, OperatingChannel))
	{
		printf("Network Created....\n\r") ;
		DumpConnection(0xff) ;
		return true ;
	}
	else
	{
		printf("Network Start Fail....\n\r") ;
		printf("Must defined as a PAN Coordinator in ConfigApp.h\r\n") ;
		return false ;
	}
}

/*** MiWiLoRa_app_join_network **************************************************
 \brief      Try to join an existing network
 \param[in]  *array  - Pointer of the array to be printed
 \param[in]   length - Length of the array
********************************************************************************/
bool MiWiLoRa_app_join_network(void)
{
	uint8_t i ;
	uint32_t OperatingChannel = 0x00300000;//0xFFFFFFFF;
	MiApp_ConnectionMode(DISABLE_ALL_CONN) ;
	//i = MiApp_SearchConnection(set_SearchDuration, (uint32_t)1<<(OperatingChannel-1));
	i = MiApp_SearchConnection(set_SearchDuration, OperatingChannel);
	//printf("scan result: %d \n\r",i);
	if(i > 0)
	{
		if( MiApp_EstablishConnection(0, CONN_MODE_DIRECT) == 0xFF )
		{
			printf("Join Fail....\n\r") ;
			return false ;
		}
		else
		{
			printf("Join Success....\n\r") ;
			DumpConnection(0xff) ;
			return true ;
		}
	}
	else
	{
		printf("\r\nNot found network... Rescan Please...... \r\n") ;
		return false ;
	}
}

bool MiWiLoRa_app_broadcast_data(uint8_t *data, uint16_t len)
{
	bool res ;
	MiApp_FlushTx() ;
	for (uint8_t i = 0; i < len; i++)
	{
		MiApp_WriteData(data[i]) ;
	}
	res = MiApp_BroadcastPacket(false) ;
	if (res)
	{
		printf("Broadcast success...\r\n") ;
	}
	else
	{
		printf("Broadcast fail...\r\n") ;
	}
	SX1276_RX_INIT() ;
	return res ;
}

bool MiWiLoRa_app_unicast_data(uint8_t *data, uint16_t len, uint8_t idx)
{
	bool res ;
	MiApp_FlushTx() ;
	for (uint8_t i = 0; i < len; i++)
	{
		MiApp_WriteData(data[i]) ;
	}
	res = MiApp_UnicastConnection(idx, false) ;
	if(res)
	{
		printf("Unicast Success...\r\n");
	}
	else
	{
		printf("Unicast fail...\r\n");
	}
	SX1276_RX_INIT() ;
	return res ;
}

void MiWiLoRa_app_display_device_info(void)
{
	printf("Channel: %d \r\n", currentChannel) ;
	printf("PANID: 0x%.4x \r\n", myPANID.Val) ;
	printf("ShortAddr: 0x%.4x \r\n", myShortAddress.Val) ;
}

// idx=0xFF to print all the connection
void MiWiLoRa_app_dump_connection(uint8_t idx)
{
	DumpConnection(idx) ;
}

uint16_t MiWiLoRa_app_get_my_short_address(void)
{
	return myShortAddress.Val ;
}


