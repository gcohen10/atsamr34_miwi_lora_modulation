#ifndef MIWI_LORA_APP_H_INCLUDED
#define MIWI_LORA_APP_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

void MiWiLoRa_app_init(void) ;
void MiWiLoRa_app_wakeup_radio(void) ;
void MiWiLoRa_app_sleep_radio(void) ;
void MiWiLoRa_app_rx(void) ;
bool MiWiLoRa_app_start_network(void) ;
bool MiWiLoRa_app_join_network(void) ;
bool MiWiLoRa_app_broadcast_data(uint8_t *data, uint16_t len) ;
bool MiWiLoRa_app_unicast_data(uint8_t *data, uint16_t len, uint8_t idx) ;
void MiWiLoRa_app_display_device_info(void) ;
void MiWiLoRa_app_dump_connection(uint8_t idx) ;
uint16_t MiWiLoRa_app_get_my_short_address(void) ;
void MiWiLoRa_app_reset_buffer(void) ;
void MiWiLoRa_app_fill_buffer(uint8_t data) ;
void MiWiLoRa_app_broadcast_buffer(void) ;
void MiWiLoRa_app_unicast_buffer(uint8_t idx) ;

#endif /* MIWI_LORA_APP_H_INCLUDED */
