// m16946
/**
* \file  app.c
*
* Copyright (c) 2019 Microchip Technology Inc. and its subsidiaries.
*
* \asf_license_start
*
* \page License
*
* Subject to your compliance with these terms, you may use Microchip
* software and any derivatives exclusively with Microchip products.
* It is your responsibility to comply with third party license terms applicable
* to your use of third party software (including open source software) that
* may accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS".  NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
* INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
* AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
* LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
* LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
* SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
* POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
* ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
* RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*
* \asf_license_stop
*
*/
/****************************** INCLUDES **************************************/
#include <asf.h>
#include "app.h"
#include "miwi_lora_app.h"
#include "conf_clocks.h"
#include "sio2host.h"
#include "extint.h"
#include "radio_driver_SX1276.h"
#include "radio_driver_hal.h"
#include "radio_get_set.h"
#include "temp_sensor.h"


/************************** Macro definition ***********************************/

/************************** Global variables ***********************************/
// Application Buffer
#define APP_BUF_SIZE	20
uint8_t broadcast_payload[APP_BUF_SIZE] = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A} ;	//1st byte cannot be 0
uint8_t unicast_payload[APP_BUF_SIZE]	= {0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAA} ;
uint8_t app_buf[APP_BUF_SIZE] = {0} ;
uint8_t app_buf_len = 0 ;
bool app_msg_received = false ;

// Temperature sensor
static float c_val ;	//�C
static float f_val ;	//�F
static char temp_sen_str[25] ;

// RTC for periodic transmission
#define TRANSMISSION_FREQUENCY	30000
enum {PERIODIC_COUNTER = 0, PERIODIC_TEMPERATURE} ;
struct rtc_module rtc_instance ;
volatile bool rtc_interrupt_flag = false ;
volatile bool periodic_tranmission_flag = false ;
uint8_t periodic_transmission_type ;

volatile bool device_is_sleeping = false ;

bool chat_mode = false ;

/************************** Extern variables ***********************************/

/****************************** FUNCTIONS **************************************/
static void print_app_menu(void) ;
static void launch_app(void) ;
static void extint_callback(void) ;
static void configure_extint_channel(void) ;
static void rtc_overflow_callback(void) ;
static void configure_rtc_count(void) ;
static void start_rtc_count(void) ;
static void stop_rtc_count(void) ;
static void switch_main_dfll(void) ;
static void configure_sleep(void) ;
static void put_radio_to_sleep(void) ;
static void enter_in_sleep(void) ;
static void start_periodic_transmission(uint8_t value) ;
static void stop_periodic_transmission(void) ;
static void wakeup(void) ;
static void init_chat(void) ;
static void enter_chat(void) ;

void app_init(void)
{
	// Init. base system
    system_init() ;
	for(uint32_t i = 0; i < 20000; i++) __NOP() ;
	delay_init() ;

	// Init. Radio hardware
	HAL_RadioInit() ;
	
	INTERRUPT_GlobalInterruptEnable() ;

	// Init. serial interface
	sio2host_init() ;

	// Init. external interrupts
    configure_extint_channel() ;
	
	// Init. sleep features
	configure_sleep() ;
	
	// Init. ADC for internal temp sensor
	temp_sensor_init() ;

	#ifdef NWK_ROLE_END_DEVICE
	// Init. RTC count
	configure_rtc_count() ;
	#endif

	// Init. MiWi LoRa app module
	MiWiLoRa_app_init() ;
	
	// App info to console
	printf("[APP_INIT]\r\n") ;
	printf("\r\n-- ATSAMR34 MiWiPRO over LoRa Sample Application --\r\n") ;
	printf("Role defined in ConfigApp.h => ") ;
	#ifdef NWK_ROLE_END_DEVICE
		printf("END DEVICE\r\n") ;
	#else
		printf("PAN COORDINATOR\r\n") ;
	#endif

	// App start
	print_app_menu() ;
}

void app_run_task(void)
{
	MiWiLoRa_app_rx() ;
	if (!chat_mode)
		launch_app() ;
	else
		enter_chat() ;
	#ifdef NWK_ROLE_END_DEVICE
	if (rtc_interrupt_flag)
	{
		rtc_interrupt_flag = false ;
		wakeup() ;
		start_periodic_transmission(periodic_transmission_type) ;
	}
	#endif
}

void app_get_message(uint8_t *data, uint8_t len)
{
	if (len <= APP_BUF_SIZE)
	{
		app_msg_received = true ;
		app_buf_len = len ;
		//sprintf(app_buf, data) ;
		memset(&app_buf, 0, sizeof(app_buf)) ;
		memcpy(app_buf, data, len) ;
	}
}

/*** print_array ****************************************************************
 \brief      Function to Print array of characters
 \param[in]  *array  - Pointer of the array to be printed
 \param[in]   length - Length of the array
********************************************************************************/
void print_array (uint8_t *array, uint8_t length)
{
    //printf("0x") ;
    for (uint8_t i =0; i < length; i++)
    {
        printf("%02x", *array) ;
        array++ ;
    }
    printf("\n\r") ;
}

static void print_app_menu(void)
{
	printf("\r\nSAMR34 MoL Firmware\r\n") ;
	printf("**************************************\r\n") ;
	printf("S: Start Network\r\n") ;
	printf("J: Join Network\r\n") ;
	printf("1: Broadcast Message\r\n") ;
	printf("2: Unicast Message\r\n") ;
#ifdef NWK_ROLE_END_DEVICE
	printf("3. Send counter value periodically\r\n") ;
	printf("4. Send temperature periodically\r\n") ;
#endif	
	printf("8: Chat\r\n") ;
	printf("9: Device Info\r\n") ;
	printf("0: Dump Connection\r\n") ;
	printf("x: Sleep\r\n") ;
	printf("\n\rH: Print Menu\r\n") ;
	printf("**************************************\r\n");
}

static void launch_app(void)
{
	char rxChar;
	if((-1) != (rxChar = sio2host_getchar_nowait()))
	{
		switch(rxChar)
		{
			case 's':
			case 'S':
				// Start network
				MiWiLoRa_app_start_network() ;
			break;
			case 'j':
			case 'J':
				// Join network
				MiWiLoRa_app_join_network() ;
			break;
			case '1':
				// Broadcast message
				MiWiLoRa_app_broadcast_data(broadcast_payload, sizeof(broadcast_payload)) ;
			break;
			case '2':
				// Unicast message
				printf("Input Connection Index:") ;
				rxChar = sio2host_getchar() ;
				printf(" %c\r\n", rxChar) ;
				rxChar = rxChar - 0x30 ;				
				MiWiLoRa_app_unicast_data(unicast_payload, sizeof(unicast_payload), rxChar) ;
			break;
			#ifdef NWK_ROLE_END_DEVICE
			case '3':
				// Start periodic transmission to Pan Coordinator
				periodic_transmission_type = PERIODIC_COUNTER ;
				app_buf[0] = 1 ;
				start_periodic_transmission(periodic_transmission_type) ;
			break ;
			case '4':
				// Start periodic transmission to Pan Coordinator
				periodic_transmission_type = PERIODIC_TEMPERATURE ;
				start_periodic_transmission(periodic_transmission_type) ;
			break ;
			#endif
			case '8':
				// Chat mode
				printf("Enter chat mode...\r\n") ;
				init_chat() ;
			break ;
			case '9':
				// Print Device info
				MiWiLoRa_app_display_device_info() ;
			break;
			case '0':
				// Dump all connection
				MiWiLoRa_app_dump_connection(0xFF) ;
			break;
			case'x':
			case 'X':
				#ifdef NWK_ROLE_END_DEVICE
					// Enter in standby mode
					enter_in_sleep() ;
				#else
					printf("Only End Device role can enter into sleep mode.\r\n") ;
				#endif
			break;
			case 'h':
			case 'H':
				// Print menu
				print_app_menu() ;
			break;
		}
	}
}

static void extint_callback(void)
{
	if (port_pin_get_input_level(BUTTON_0_PIN) == BUTTON_0_ACTIVE)
	{
		#ifdef NWK_ROLE_END_DEVICE
		if (device_is_sleeping)
		{
			wakeup() ;
		}
		#endif
		#ifdef NWK_ROLE_END_DEVICE
		if (periodic_tranmission_flag)
		{
			stop_periodic_transmission() ;
		}
		#endif		
		delay_ms(50) ;
		while(port_pin_get_input_level(BUTTON_0_PIN) == BUTTON_0_ACTIVE)
		{
			delay_ms(500) ;
		}
	}
}

static void configure_extint_channel(void)
{
	struct extint_chan_conf config_extint_chan;
	extint_chan_get_config_defaults(&config_extint_chan);
	config_extint_chan.gpio_pin           = BUTTON_0_EIC_PIN;
	config_extint_chan.gpio_pin_mux       = BUTTON_0_EIC_MUX;
	config_extint_chan.gpio_pin_pull      = EXTINT_PULL_UP;
	config_extint_chan.detection_criteria = EXTINT_DETECT_BOTH;
	extint_chan_set_config(BUTTON_0_EIC_LINE, &config_extint_chan);
	extint_register_callback(extint_callback,BUTTON_0_EIC_LINE,EXTINT_CALLBACK_TYPE_DETECT);
	extint_chan_enable_callback(BUTTON_0_EIC_LINE,EXTINT_CALLBACK_TYPE_DETECT);
	while (extint_chan_is_detected(BUTTON_0_EIC_LINE)) {
		extint_chan_clear_detected(BUTTON_0_EIC_LINE);
	}
}

static void rtc_overflow_callback(void)
{
	rtc_interrupt_flag = 1 ;
	port_pin_toggle_output_level(LED_0_PIN) ;
}

// Configure RTC for 30 seconds
static void configure_rtc_count(void)
{
	struct rtc_count_config config_rtc_count ;
	rtc_count_get_config_defaults(&config_rtc_count) ;
	config_rtc_count.prescaler = RTC_COUNT_PRESCALER_DIV_32 ;
	config_rtc_count.mode = RTC_COUNT_MODE_16BIT ;
	#ifdef FEATURE_RTC_CONTINUOUSLY_UPDATED
	config_rtc_count.continuously_update = true ;
	#endif
	rtc_count_init(&rtc_instance, RTC, &config_rtc_count) ;
	rtc_count_set_period(&rtc_instance, TRANSMISSION_FREQUENCY) ;
	rtc_count_enable(&rtc_instance);
}

// Start RTC counting
static void start_rtc_count(void)
{
	rtc_count_set_count(&rtc_instance, 0) ;
	rtc_count_register_callback(&rtc_instance, rtc_overflow_callback, RTC_COUNT_CALLBACK_OVERFLOW) ;
	rtc_count_enable_callback(&rtc_instance, RTC_COUNT_CALLBACK_OVERFLOW) ;
}

// Stop RTC counting
static void stop_rtc_count(void)
{
	rtc_count_disable_callback(&rtc_instance, RTC_COUNT_CALLBACK_OVERFLOW) ;
}

// Switch the main clock to dfll after wake up. Reference GCLK1 is already enabled with XOSC32K
static void switch_main_dfll(void)
{
	struct system_gclk_gen_config gclk_conf;
	struct system_gclk_chan_config dfll_gclk_chan_conf;

	system_gclk_chan_get_config_defaults(&dfll_gclk_chan_conf);
	dfll_gclk_chan_conf.source_generator = GCLK_GENERATOR_1;
	system_gclk_chan_set_config(OSCCTRL_GCLK_ID_DFLL48, &dfll_gclk_chan_conf);
	system_gclk_chan_enable(OSCCTRL_GCLK_ID_DFLL48);

	struct system_clock_source_dfll_config dfll_conf;
	system_clock_source_dfll_get_config_defaults(&dfll_conf);

	dfll_conf.loop_mode      = SYSTEM_CLOCK_DFLL_LOOP_MODE_CLOSED;
	dfll_conf.on_demand      = false;
	dfll_conf.run_in_stanby  = CONF_CLOCK_DFLL_RUN_IN_STANDBY;
	dfll_conf.multiply_factor = CONF_CLOCK_DFLL_MULTIPLY_FACTOR;
	system_clock_source_dfll_set_config(&dfll_conf);
	system_clock_source_enable(SYSTEM_CLOCK_SOURCE_DFLL);
	while(!system_clock_source_is_ready(SYSTEM_CLOCK_SOURCE_DFLL));
	if (CONF_CLOCK_DFLL_ON_DEMAND) {
		OSCCTRL->DFLLCTRL.bit.ONDEMAND = 1;
	}

	/* Select DFLL for main clock. */
	system_gclk_gen_get_config_defaults(&gclk_conf);
	gclk_conf.source_clock = SYSTEM_CLOCK_SOURCE_DFLL;
	gclk_conf.division_factor= CONF_CLOCK_GCLK_0_PRESCALER;
	system_gclk_gen_set_config(GCLK_GENERATOR_0, &gclk_conf);
}

// 
static void configure_sleep()
{
	/* Disable BOD33 */
	SUPC->BOD33.reg &= ~(SUPC_BOD33_ENABLE) ;

	/* Select BUCK converter as the main voltage regulator in active mode */
	SUPC->VREG.bit.SEL = SUPC_VREG_SEL_BUCK_Val ;

	/* Wait for the regulator switch to be completed */
	while(!(SUPC->STATUS.reg & SUPC_STATUS_VREGRDY)) ;
	
	/* Set Voltage Regulator Low power Mode Efficiency */
	SUPC->VREG.bit.LPEFF = 0x1 ;
	
	PM->STDBYCFG.reg = PM_STDBYCFG_BBIASHS(1) | PM_STDBYCFG_VREGSMOD_LP ;

	/* Apply SAM L21 Erratum 15264 */
	SUPC->VREG.bit.RUNSTDBY = 0x1 ;
	SUPC->VREG.bit.STDBYPL0 = 0x1 ;
}

static void enter_in_sleep(void)
{
	device_is_sleeping = true ;

	temp_sensor_deinit() ;	
	MiWiLoRa_app_sleep_radio() ;

	// RF Switch Turned off
	struct port_config pin_conf ;
	port_get_config_defaults(&pin_conf) ;
	pin_conf.direction  = PORT_PIN_DIR_OUTPUT ;
	port_pin_set_config(RF_SWITCH_PIN, &pin_conf) ;
	port_pin_set_output_level(RF_SWITCH_PIN, RF_SWITCH_INACTIVE) ;
	
	printf("Sleep..\r\n") ;
	printf("Press SW0 to wake up the device...\r\n") ;

	/* Switch GCLK GEN 0 source to DFLL */
	GCLK->GENCTRL[0].reg =(GCLK_GENCTRL_SRC_XOSC32K | GCLK_GENCTRL_GENEN |GCLK_GENCTRL_RUNSTDBY) ;
	/* Wait for the synchronization between clock domains */
	while((GCLK->SYNCBUSY.reg & GCLK_SYNCBUSY_GENCTRL_GCLK0)) continue ;
	
	system_set_sleepmode(SYSTEM_SLEEPMODE_STANDBY) ;
	system_sleep() ;
}

static void start_periodic_transmission(uint8_t value)
{
	periodic_tranmission_flag = true ;
	printf("***************************\r\n") ;
	if (value == PERIODIC_COUNTER)
	{
		printf("Periodic transmission. Sending counter [%02d] every %ld ms.Press SW0 button to stop.\r\n", app_buf[0], TRANSMISSION_FREQUENCY) ;
		if (MiWiLoRa_app_unicast_data(app_buf, 1, 0) == true)
		 app_buf[0]++ ;		
	}
	else
	{
		get_temp_sensor_data((uint8_t*)&c_val) ;
		f_val = convert_celsius_to_fahrenheit(c_val) ;
		snprintf(app_buf, sizeof(app_buf), "%.1fC/%.1fF", c_val, f_val) ;
		printf("Periodic transmission. Sending current temperature [%.1f\xf8 C/%.1f\xf8 F] every %ld ms.Press SW0 button to stop.\r\n", c_val, f_val, TRANSMISSION_FREQUENCY) ;
		MiWiLoRa_app_unicast_data(app_buf, strlen(app_buf), 0) ;
	}

	start_rtc_count() ;
	enter_in_sleep() ;
}

static void stop_periodic_transmission(void)
{
	stop_rtc_count() ;	
	periodic_tranmission_flag = false ;
	rtc_interrupt_flag = false ;
	printf("Stop periodic transmission\r\n") ;
}

static void wakeup(void)
{
	device_is_sleeping = false ;
	switch_main_dfll() ;
	MiWiLoRa_app_wakeup_radio() ;
	temp_sensor_init() ;
	sio2host_init() ;
	printf("Wake up...\r\n") ;	
}

static void init_chat(void)
{
	chat_mode = true ;
	// prepare the buffer
	MiWiLoRa_app_reset_buffer() ;
}

static void enter_chat(void)
{
	char rxChar ;
	uint8_t data[1] = {0} ;
	if((-1) != (rxChar = sio2host_getchar_nowait()))
	{
		if (rxChar >= 32 && rxChar <= 125)
		{
			MiWiLoRa_app_fill_buffer(rxChar - 0x30) ;
		}
		else if (rxChar == 0x0D)
		{
			// pressed enter
			printf("\r\n") ;
			MiWiLoRa_app_broadcast_buffer() ;
			init_chat() ;
		}
	}
}
