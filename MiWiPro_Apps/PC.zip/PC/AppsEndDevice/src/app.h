#ifndef APP_H_INCLUDED
#define APP_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

void app_init(void) ;
void app_run_task(void) ;
void app_get_message(uint8_t *data, uint8_t len) ;
void print_array (uint8_t *array, uint8_t length) ;

#endif /* APP_H_INCLUDED */
