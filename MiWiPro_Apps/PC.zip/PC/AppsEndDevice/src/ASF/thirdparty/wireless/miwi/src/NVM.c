﻿/*
 * NVM.c
 *
 * Created: 2019-08-08 오후 3:20:08
 *  Author: A14633
 */ 

#include "NVM.h"

 uint16_t        nvmMyMemory;
 uint16_t        nvmMyPANID;
 uint16_t        nvmCurrentChannel;
 uint16_t        nvmConnMode;
 uint16_t        nvmConnectionTable;
 uint16_t        nvmOutFrameCounter;
 
 uint16_t        nvmMyShortAddress;
 uint16_t        nvmMyParent;
 
 uint16_t    nvmRoutingTable;
 uint16_t    nvmNeighborRoutingTable;
 uint16_t    nvmFamilyTree;
 uint16_t    nvmRole;
 

void NVMRead(uint8_t *dest, uint16_t addr, uint16_t count)
{
	
}

void NVMWrite(uint8_t *source, uint16_t addr, uint16_t count)
{
	
}

void i2c_EEPROM_Read(uint8_t *dest, uint16_t address, uint16_t count)
{
	
}

void i2c_EEPROM_Write(uint8_t *source, uint16_t address, uint16_t count)
{
	
}

bool NVMInit(void)
{
	return true;
}